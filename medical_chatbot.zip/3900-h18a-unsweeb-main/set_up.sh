#!/bin/sh

npm i
cd web-fe
npm i