<template>
  <div>{{ props.initials }}</div>
</template>
<script setup>
  const props = defineProps(['initials'])
</script>
<style scoped>
div {
  background: #00d1b2;
  color: white;
  opacity: 1; 
  display: inline-block; 
  font-weight: bold; 
  font-size: 25px;
  border-radius: 50%; 
  vertical-align: middle; 
  margin-right: 0.5em; 
  margin-top: 10px;
  width: 80px; 
  height: 80px; 
  line-height: 80px; 
  text-align: center; 
}

</style>