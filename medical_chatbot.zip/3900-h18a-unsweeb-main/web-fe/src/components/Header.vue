<template>
	<nav class="row navbar" role="navigation" aria-label="main navigation">
    <div class="navbar-brand">
      <a class="navbar-item" @click="router.push('/')">
        <img src="../assets/logo.svg" >
      </a>
      <a class="navbar-item" @click="router.push('/')">
        <strong>Med Bot</strong>
      </a>
    </div>
    <div class="navbar-end">
      <div class="navbar-item">
        <div class="buttons">
          <a class="button is-link is-outlined" @click="login">Login</a>
          <a class="button is-ghost" @click="aauth">Login with aauth</a>
        </div>
      </div>
    </div>
  </nav>
</template>
<script setup>
import { useRouter } from 'vue-router'
const router = useRouter()
// direct to login page
const login = () => {
  router.push('/login')
}
// direct to login with aauth
const aauth = async () => {
  await new Promise((resolve, reject) => setTimeout(resolve, 500))
  if (window.sessionStorage.token) router.push('/chat')
  else window.location.href = 'https://aauth.link/#/launch/dxc0cxyjneenoc5lancpq1kw44wj3c'
}
</script>