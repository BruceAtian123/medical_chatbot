<template>
  <nav class="panel" style="box-shadow: 0; height: 100vh">
    <div class="row" >
      <Avatar :initials="SS.username[0]"/>
    <h1>Dr. {{ SS.username }}</h1>
  </div>
    <aside class="menu">
      <ul class="menu-list">
        <li class="has-text-left" @click="editProfile" >
          <a :style="theme.fontcolor">Edit Profile</a>
        </li>
        <li class="has-text-left" @click="isSearch=true">
          <a :style="theme.fontcolor">Search Chat History</a>
        </li>
        <li class="has-text-left" @click="download = !download">
          <a :style="theme.fontcolor">Download source code</a>
          <ul v-if="download">
            <li class="has-text-left">
              <a :style="theme.fontcolor" href="http://46.101.154.24:5000/file/9961b078f46bdb5a84f0b67aeaff4a6c" target="_blank">click here to download</a></li>
          </ul>
        </li>
        <li class="has-text-left" @click="platforms = !platforms">
          <a :style="theme.fontcolor">Use Bot on Other Platform</a>
          <ul v-if="platforms">
            <li class="has-text-left"><a :style="theme.fontcolor">Use In Telegram: Search for @Pikachu_bbbbbot</a>
            </li>
            <li class="has-text-left"><a :style="theme.fontcolor">Use In Slack: /link/ </a>
            </li>
          </ul>
        </li>
        <li class="has-text-left">
          <a :style="theme.fontcolor">Commands</a>
          <ul>
            <li class="has-text-left">
              <a :style="theme.fontcolor">To start a conversation: 
                <strong style="color: #00d1b2">\start</strong>
              </a>
            </li>
            <li class="has-text-left">
              <a :style="theme.fontcolor">To Stop a conversation: 
                <strong style="color: #00d1b2">\stop</strong>
              </a>
            </li>
             <li class="has-text-left">
              <a :style="theme.fontcolor">To change mode: 
                <strong style="color: #00d1b2">\changemode</strong>
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </aside>
  </nav>

  <div v-if="isSearch" class="modal" style="display: block">
    <div class="modal-background"></div>
    <div class="modal-content" style="margin-top: 15px">
      <h1 class="title is-4" style="color:white">Search in Chat History</h1>
      <div style=" display: flex;justify-content: space-between; margin-bottom: 15px">
        <div class="control has-icons-left" :class="loading" style="width: 85%;">
          <input
                class="input"
                type="text"
                v-model="searchText"
                placeholder="Search"
                @keyup.enter="searchChatHistory"
              />
          <span class="icon is-left">
            <i class="fas fa-search" aria-hidden="true"></i>
          </span>
        </div>
        <button class="button is-primary is-light" @click="searchChatHistory">Search</button>
      </div>
      <div
          class="card"
          v-for="sr in searchResult"
           :key="sr._id"
          style="width: '100%';'background-color': #fff"
        >
          <div class="card-content has-text-left">
            <p><strong>{{ sr.user }}</strong > &nbsp;{{ timeConverter(sr.timestamp) }}</p>
            <pre>{{ sr.content }}</pre>
            <div v-if="sr.imgUrl !== '' && sr.imgUrl !== undefined" class="card-image">
              <figure class="image is-4by3">
                <img :src="sr.imgUrl" alt="Placeholder image" />
              </figure>
            </div>
          </div>
        </div>
    </div>
    <button class="modal-close is-large" aria-label="close" @click="isSearch=false"></button>
  </div>
</template>
<script setup>
import { useRouter } from 'vue-router'
import { reactive, computed } from 'vue'
import Avatar from './Avatar.vue'
const router = useRouter()
ref: isSearch = false
ref: download = false
ref: platforms = false
ref: searchText = ""
ref: searchResult = []
ref: loading = ""
const SS = window.sessionStorage
const editProfile = () => {
  router.push("/profile")
}
// change theme
const theme = reactive({
  bgcolor: computed(() => SS.darkmode === "true" ? "background-color: #363636" : "background-color: white"),
  fontcolor: computed(() => SS.darkmode === "true"? "color: white": "")
})
// Search in chat history
const searchChatHistory = async () => {
  loading = "is-loading"
  if (searchText === "") {
    loading = ""
    searchResult = []
    return
  }
  axios.get(`/api/message/history`, {
    params: {
      search: searchText
    },
    headers: { 
      token: SS.token
    }
  })
  .then(res => {
    searchResult = res.data.reverse()
    loading = ""
    console.log(searchResult[0])
  })
  .catch(err => {
    swal.fire("No related chat history", "", "error")
    loading = ""
  })
}
// Get date from unix timestamp
function timeConverter(timestamp){
  const a = new Date(timestamp)
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
  const year = a.getFullYear()
  const month = months[a.getMonth()]
  const date = a.getDate()
  const hour = a.getHours()
  const min = a.getMinutes()
  const sec = a.getSeconds()
  return date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec
}
</script>
<style scoped>
a:hover {
  background-color: #757575;
  color: white;
}
</style>