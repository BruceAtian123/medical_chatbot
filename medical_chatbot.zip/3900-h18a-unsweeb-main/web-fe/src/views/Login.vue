<template>
  <Header />
  <div class="login box">
    <div class="box form">
      <h1 class="title" style="margin-bottom: 16px">Med Bot</h1>
      <p class="tip">Login</p>
      <transition name="fade" mode="out-in">
        <div v-if="step === 'username'">
          <div class="control has-icons-left" style="margin-bottom: 24px">
            <input
              class="input is-primary is-medium"
              style="width: 280px"
              type="text"
              placeholder="username"
              v-model="username"
              @keyup.enter="confirmUsername"
            />
            <span class="icon is-left">
              <i class="mdi mdi-24px mdi-account-circle"></i>
            </span>
            <p style="margin-top: 4px;">Don't have an account? <a @click="router.push('/signup')">Sign up here</a></p>
          </div>

          <button
            class="button is-primary is-rounded is-medium"
            :disabled="!username"
            :class="{ 'is-loading': loading }"
            @click="confirmUsername"
          >
            <span class="icon">
              <i class="mdi mdi-24px mdi-arrow-right"></i>
            </span>
          </button>
        </div>

        <div v-else>
          <div class="control has-icons-left" style="margin-bottom: 24px">
            <input
              class="input is-primary is-medium"
              style="width: 280px"
              type="password"
              placeholder="password"
              v-model="password"
              @keyup.enter="confirmPassword"
              ref="input"
            />
            <span class="icon is-left">
              <i class="mdi mdi-24px mdi-key"></i>
            </span>
            <p class="message" :style="{ 'color': msg.color }">{{ msg.text }}</p>
          </div>

          <button
            class="button is-primary is-rounded is-medium"
            :disabled="!password"
            :class="{ 'is-loading': loading }"
            @click="confirmPassword"
          >
            <span class="icon">
              <i class="mdi mdi-24px mdi-check"></i>
            </span>
          </button>
        </div>
      </transition>
    </div>
  </div>
</template>

<script setup>
import { computed, reactive, watch, nextTick } from 'vue'
import Hashes from 'jshashes'
import { useRouter, useRoute } from 'vue-router'
import Header from '../components/Header.vue'
const router = useRouter()
const route = useRoute()
const SS = window.sessionStorage
const sha256 = (msg) => new Hashes.SHA256().b64(msg)


const msg = reactive({
  text: '',
  err: false,
  color: computed(() => msg.text ? (msg.err ? '#f5222d' : '#00c4a7') : '#fff')
})
const clearMsg = () => {
  msg.text = ''
  msg.err = false
}

ref: loading = false
ref: username = ''
ref: password = ''
ref: input = null
ref: step = "username"

watch($username, clearMsg)
watch($password, clearMsg)

const confirmUsername = () => {
  step = "password"
}
const confirmPassword = () => {
  loading = true
  axios.post('/api/user/login', { username, "password": sha256(password) })
    .then(res => {
      SS.token = res.data
      router.push('/chat')
    })
    .catch(err => {
      swal.fire('Error', err.response ? err.response.data : 'Network Error', 'error')
      step = 'username'
      loading = false
      username = password = ''
    })
}
</script>

<style>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>

<style scoped>
div.login {
  color: #333;
  background: #f2f2f2;
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
}
p.tip {
  position: relative;
  font-size: 1.2em;
  font-weight: bold;
  width: 100%;
  color: #555;
  margin: 10px 0 20px;
}
p.message {
  background: #fff;
  padding-left: 8px;
  text-align: left;
  font-size: 0.8em;
  height: 0.8em;
  transition: all 0.5s ease;
}
.form {
  height: 310px;
  padding: 36px 100px;
  margin-bottom: 50px;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
}
@media (max-width: 500px) {
  .form {
    width: 100%;
    padding: 30px 10px;
  }
}
</style>