<template>
  <div class="login">
    <h1 style="margin-bottom: 50px; font-size: 3rem;">Medbot system</h1>
    <h2>{{ notice }}</h2>
  </div>
</template>
<script setup>
import axios from 'axios'
import { onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
const router = useRouter()
const route = useRoute()
const SS = window.sessionStorage
ref: notice = 'Logining...'
onMounted (() => {
	const code = route.query.code
  if (!code) {
    notice = 'Opps, wrong page!'
    setTimeout(() => { router.push('/') }, 3000)
    return
  }
  axios.post('/api/user/', { code })
    .then(resp => {
    const s = resp.data.split('.')
    SS.token = resp.data
    notice = 'Login success, redirecting...'
    setTimeout(() => { router.push('/chat') }, 1000)
    })
    .catch(err => {
    notice = err.response ? err.response.data : 'Network error'
    setTimeout(() => { router.push('/') }, 3000)
    })
})
</script>
<style scoped>
div.login {
  color: #333;
  height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
</style>