<template>
  <Header />
  <div class="signup box">
    <div class="box form">
      <h1 class="title" style="margin-bottom: 16px">Med Bot</h1>
      <p class="tip" style="margin-bottom: 16px">Sign Up</p>
      <div class="rows is-mobile is-multiline is-centered" style="margin-bottom: 24px">
        <div class="row textbox">
          <div class="control has-icons-left" style="margin-bottom: 24px">
            <input
              class="input is-primary is-medium"
              style="width: 280px"
              type="text"
              placeholder="username"
              v-model="username"
            />
            <span class="icon is-left">
              <i class="mdi mdi-24px mdi-account-circle"></i>
            </span>
           </div> 
        </div>
        <div class="row textbox">
          <div class="control has-icons-left" style="margin-bottom: 24px">
            <input
              class="input is-primary is-medium"
              style="width: 280px"
              type="password"
              placeholder="password"
              v-model="password"
              @keyup.enter="confirmPassword"
              ref="input"
            />
            <span class="icon is-left">
              <i class="mdi mdi-24px mdi-key"></i>
            </span>
          </div>
        </div>

        <div class="row">
          <div class="control has-icons-left">
          <input
              class="input is-primary is-medium"
              style="width: 280px"
              type="password"
              placeholder="confirm password"
              v-model="repassword"
              @keyup.enter="confirmPassword"
              ref="input"
            />
            <span class="icon is-left">
              <i class="mdi mdi-24px mdi-key"></i>
            </span>
          </div>
        </div>
        <p class="message" style="margin: 0px;" :style="{ 'color': msg.color }">{{ msg.text }}</p>
        <button
          class="button is-primary is-rounded is-medium"
          :disabled="!finish"
          :class="{ 'is-loading': loading }"
          @click="signup"
          style="margin-top: 10px"
        >
          <span class="icon">
            <i class="mdi mdi-24px mdi-check"></i>
          </span>
        </button>
      </div>
    </div>
  </div>
</template>
<script setup>
import { computed, reactive, watch, nextTick } from 'vue'
import Hashes from 'jshashes'
import { useRouter, useRoute } from 'vue-router'
import axios from 'axios'
import Header from '../components/Header.vue'
const router = useRouter()
const route = useRoute()
const sha256 = (msg) => new Hashes.SHA256().b64(msg)
const SS = window.sessionStorage

const msg = reactive({
  text: '',
  err: false,
  color: computed(() => msg.text ? (msg.err ? '#f5222d' : '#00c4a7') : '#fff')
})

const clearMsg = () => {
  msg.text = ''
  msg.err = false
}

ref: loading = false
ref: username = ''
ref: email = ''
ref: password = ''
ref: repassword = ''
ref: random = ''
ref: input = null
ref: step = "username"
ref: token = ''

function init() {
  if (SS.username) username = SS.username
}
init()

const finish = computed(() => (username.length > 0 && confirmPassword()) ? true : false)

const confirmPassword = () => {
  clearMsg()
  if (password.length <= 0 || repassword.length <= 0 || password !== repassword) {
    msg.text = "Passwords not match"
    msg.err = true
    return false
  }
  return true
}

async function signup() {
  axios.post('/api/user/register', { username, "password": sha256(password), "role": "Doctor"})
    .then(res => {
      SS.token = res.data
      router.push('/chat')
    })
    .catch(err => {
      swal.fire('Error', err.response ? err.response.data : 'Network Error', 'error')
      return false
    })
}

</script>
<style scoped>
div.signup {
  color: #333;
  background: #f2f2f2;
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
}
.form {
  height: 430px;
  padding: 36px 100px;
  margin-bottom: 50px;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.textbox {
  margin-bottom: 16px;
}
</style>