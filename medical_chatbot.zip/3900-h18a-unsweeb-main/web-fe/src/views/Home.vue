<template>
  <div>
    <Header />
    <h1 class="title" style="margin-top: 40px">Medical Assistant Bot</h1>
    <div style="margin: auto;">
      <input class="input is-primary is-medium" style="width: 280px; margin-right: 20px" placeholder="Enter username" v-model="username"/>
      <a class="button is-primary large" style="height: 50px;" @click="signup">Sign Up</a>
    </div>
    <div>
      <img src="../assets/logo.svg" >
    </div>
  </div>
</template>
<script setup>
import { useRouter } from 'vue-router'
import Header from '../components/Header.vue'
const router = useRouter()
const SS = window.sessionStorage
ref: username = ""
// direct to sign up page
const signup = () => {
  SS.username = username
  router.push('/signup')
}

</script>
<style scoped>
h1 {
  font-size: 3em
}
</style>