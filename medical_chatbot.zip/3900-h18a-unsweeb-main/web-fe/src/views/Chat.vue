<template>
  <div class="columns" style="min-height: 100vh" :style="theme.bgcolor">
    <div class="column is-one-quarter">
      <nav class="panel is-primary" style="box-shadow: 0; min-height: 100vh">
        <h1 class="panel-heading" style="border-radius: 0;">Chats</h1>
        <div class="panel-block">
          <p class="control has-icons-left">
            <input
              class="input"
              type="text"
              v-model="botSearchText"
              @keyup.enter="searchBot"
              placeholder="Search"
            />
            <span class="icon is-left">
              <i class="fas fa-search" aria-hidden="true"></i>
            </span>
          </p>
        </div>
        <a class="panel-block is-active" :style="theme.fontcolor">
          <span v-if="bot === 'Med Assistant Bot'" class="panel-icon">
            <i class="fas fa-user" aria-hidden="true"></i>
          </span>
          {{ bot }}
        </a>
      </nav>
    </div>
    <div class="column is-half">
      <div class="is-fixed-top" style="padding: 20px 20px 10px 20px;" >
        <h1 class="title" :style="theme.fontcolor">Med Bot</h1>
      </div> 
      <hr style="margin: 0px" />
      <div class="bottom-aligner">
        <div class="scroll" style="overflow: auto; height: 650px;">
          <div
            class="card"
            v-for="m in messages"
            :key="m.id"
            style="width: '100%';'background-color': #fff"
            :style="theme.bgcolor"
          >
            
            <div class="card-content has-text-left">
              <p :style="theme.fontcolor"><strong :style="{
                color: cardColor(m.publisher)
              }" >{{ m.publisher }}</strong > &nbsp;{{ m.time }}</p>
              <pre :style="theme.all " style="overflow-wrap: anywhere;">{{ m.content }}</pre>
              <div v-if="m.imgUrl !== '' && m.imgUrl !== undefined" class="card-image">
                <figure class="image" style="width: 60%">
                  <img :src="m.imgUrl" alt="Placeholder image" />
                </figure>
              </div>
            </div>
          </div>
        </div>
        <nav class="nav-bar is-fixed-bottom" style="margin-top: 10px; margin-bottom: 10px;">
          <div class="navbar-end">
            <input
              :disabled=responding
              class="input"
              type="text"
              v-model="msg"
              @keyup.enter="sent"
              placeholder="Type in your message"
            />
            <div class="navbar-item" style="color: #00d1b2" @click="sent">
              <i class="icon fas fa-paper-plane" ></i>
            </div>
            <div class="file navbar-item" :style="theme.fontcolor">
              <input class="file-input" type="file" v-on:change="uploadfile" />
              <i class="icon fas fa-paperclip"></i>
            </div>
            <span class="navbar-icon navbar-item" @click="record" :style="theme.fontcolor">
              <div v-if="!recording" >
                <i class="fas fa-microphone"></i>
              </div>
              <div v-else><i class="fas fa-stop-circle"></i></div>
            </span>
          </div>
        </nav>
      </div>
    </div>
    <div class="column is-one-quarter" :style="theme.fontcolor">
      <ChatInfo/>
    </div>
  </div>
</template>
<script setup>
import axios from "axios";
import "bulma-floating-button/dist/css/bulma-floating-button.min.css"
import { computed, reactive, watch, onMounted, ref } from "vue"
import { useRouter, useRoute } from "vue-router"
import ChatInfo from '../components/ChatInfo.vue'

ref: messages = []
ref: msg = ""
ref: botSearchText = ""
ref: bot = "Med Assistant Bot"
ref: file = null
ref: imgUrl = ""
ref: recording = false
ref: loading = false
ref: responding = false

const router = useRouter()
const route = useRoute()
const SS = window.sessionStorage

async function chooseMode() {
  await swal
      .fire({
        title: "Please choose one of the mode",
        confirmButtonText: "Chat mode",
        cancelButtonText: "Search mode",
        showCancelButton: true,
        showCloseButton: true,
      })
      .then((res) => {
        if (res.isConfirmed) {
          Swal.fire("You have chosen chat mode!", "", "success")
          SS.mode = "chat"
        } else {
          Swal.fire("You have chosen search mode!", "", "success")
          SS.mode = "search"
        }
      })
}

const sent = async () => {
  if (msg === '') {
    await swal.fire("Can't send empty message", '', 'error')
    return
  }
  if (msg === "\\start" || msg === "\\changemode") {
    if (msg === "\\start") { 
      messages.push({ content: 'Hello, how are you?', publisher: "bot", imgUrl: '', time: timeConverter(Date.now()) })
    }
    if (SS.mode) {
      await swal
        .fire({
          title: "Do you want to use the mode selected last time?",
          confirmButtonText: "Yes",
          cancelButtonText: "No",
          showCancelButton: true,
          showCloseButton: true,
        })
        .then((res) => {
          if (res.isConfirmed) {
            Swal.fire(`You have chosen ${SS.mode} mode!`, "", "success");
          } else {
            chooseMode()
          }
        })
    } else {
      await chooseMode()
    }
    msg = ''
    responding = false
    return
  } else if (msg === "\\stop") {
    await swal
      .fire({
        title: "Are you sure you want to stop the chat?",
        content: "You can press any key to continue",
        confirmButtonText: "Yes",
        cancelButtonText: "Stay",
        showCancelButton: true,
        showCloseButton: true,
      })
      .then((res) => {
        if (res.isConfirmed) {
          Swal.fire("Bye!", "", "success");
        } else {
          Swal.fire("Glad you stayed", "", "success");
        }
      });
    responding = false
    msg = ""
    return;
  }
  if (!SS.mode || SS.mode === "") {
    swal.fire(
      "You haven't choose mode",
      "Please send `\\start` to choose mode",
      "warning"
    );
    responding = false
    return
  }

  if (file) {
    loading = true
    const formData = new FormData()
    formData.append("file", file, file.name)
    try {
      const res = await axios.post(
        "http://46.101.154.24:5000/upload",
        formData,
        { headers: { token: SS.id } }
      );
      SS.mode = 'image'
      imgUrl = "http://46.101.154.24:5000/file/" + res.data.hash
      swal.fire("Image uploaded, mode switched to image mode automatically", "", "success");
    } catch (err) {
      swal.fire("Image upload failed", "error", "error");
    }
    loading = false
  }
  if (SS.mode !== 'image') { imgUrl = "" }

  
  messages.push({ content: msg, publisher: SS.username, imgUrl, time: timeConverter(Date.now()) });
  messages.push({ content: "I'm thinking...", publisher: "bot", imgUrl:"", time: timeConverter(Date.now()) })
  responding = true
  scrolldown()

  // send to bot and get response
  let path = "/api/message/"
  if (SS.mode == 'search') path += 'search'
  else if (SS.mode == 'chat' || SS.mode == 'image') path += 'send'
  axios
    .post(
      path,
      { content: msg, imageUrl: imgUrl, timestamp: Date.now() },
      { headers: { token: SS.token } }
    )
    .then((res) => {
      let data = res.data
      if (SS.mode === "search") {
        data = niceJson(data)
      }
      messages.pop()
      messages.push({ content: data, publisher: "bot", imgUrl: '', time: timeConverter(Date.now()) })
      
      scrolldown()
      responding = false
    })
    .catch((err) => {
      swal.fire("Error!", err, 'error')
      responding = false
    })
  scrolldown();
  msg = "";
  file=null;
};

function timeConverter(timestamp){
  const a = new Date(timestamp)
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
  const year = a.getFullYear()
  const month = months[a.getMonth()]
  const date = a.getDate()
  const hour = a.getHours()
  const min = a.getMinutes()
  const sec = a.getSeconds()
  return date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec
}

async function init() {
  if (! SS.token) {
    await swal.fire('Please Login', '', 'error')
    router.push('/login')
  }
  SS.username = SS.token.split('.')[3]
  SS.role = SS.token.split('.')[2]
  // get chat history
  const time = (Date.now() - 86400000)
  axios.get(`/api/message/fetch/${time}`, { headers: { token: SS.token } })
    .then(res => {
      for (const m of res.data) {
        if (m.user == 'bot') {
          if (Array.isArray(m['content'])) {
            m['content'] = niceJson(m['content'])
          }
          messages.push({content: m['content'], publisher: "bot", imgUrl: '', time: timeConverter(m['timestamp'])})
        } else {
          messages.push({content: m['content'], publisher: SS.username, imgUrl: m['imageUrl'], time: timeConverter(m['timestamp'])})
        }

      }
    })
    .catch(err => {
      swal.fire("Error!", err, 'error')
    })
}
init()

function niceJson (data) {
  let niceData = ""
  for (let d of data) {
    d = JSON.stringify(d, null, 4)
    d = d.replaceAll(/ *[[\]"{}] */ig, '')
    d = d.replaceAll('\n,\n', '')
    d = d.replaceAll('\s+', '\n')
    d = d.replaceAll('.,', '.')
    d = d.replaceAll('\n+', '\n')
    d = d.replaceAll(/accession_number:?,?/ig, 'ACCESSION_NUMBER\n')
    d = d.replaceAll(/exam_description:?,?/ig, '\nEXAM_DESCRIPTION\n')
    d = d.replaceAll(/input_file:?,?/ig, '\nINPUT_FILE\n')
    d = d.replaceAll(/paragraphs:?,?/ig, '\nPARAGRAPHS')
    d = d.replaceAll(/findings:?,?/ig, '\nFINDINGS\n')
    d = d.replaceAll(/conclusion:?,?/ig, '\nCONCLUSION\n')

    niceData += d
    niceData += "\n============================================\n"
  }
  return niceData
}

async function uploadfile(e) {
  loading = true
  const files = e.target.files || e.dataTransfer.files;
  if (!files.length) return;
  file = files[0]
  loading = false
  await swal.fire("file uploaded", '', 'success')
}

function scrolldown() {
  const el = document.getElementsByClassName("scroll")[0]
  el.scrollTop = el.scrollHeight
}

onMounted(() => { scrolldown(); })


const cardColor = (publisher) => (publisher === "bot" ? "#000" : "#00d1b2");
const fontcolor = (publisher) => (publisher === "bot" ? "#BDBDBD" : "#fff");
const float = (publisher) => (publisher === "bot" ? "left" : "right");

const searchBot = async () => {
  const regex = new RegExp(botSearchText);
  if (!regex.test(bot)) {
    bot = "No result found";
    await new Promise((resolve, reject) => setTimeout(resolve, 3000));
    bot = "Med Assistant Bot";
    botSearchText = "";
  }
}
// speech Recognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
const recognition = new SpeechRecognition()
//  enable users to speak with longer pauses between words and phrases
recognition.continuous = true
recognition.onstart = function() { 
  swal.fire('Voice recognition activated. Try speaking into the microphone.','','info')
}

recognition.onspeechend = function() {
  swal.fire('You were quiet for a while so voice recognition turned itself off.', '', 'success')
}

recognition.onerror = function(event) {
  if(event.error == 'no-speech') {
    swal.fire('No speech was detected. Try again.','','error')
  }
}
recognition.onresult = function(event) {
  // event is a SpeechRecognitionEvent object.
  // We only need the current one.
  const current = event.resultIndex;
  msg = event.results[current][0].transcript;
}

// record and turn to transcript
function record () {
  if (!recording) {
    recognition.start()
  } else {
    recognition.stop()
  }
  recording = !recording
}

// change theme
const theme = reactive({
  bgcolor: computed(() => SS.darkmode  === "true" ? "background-color: #363636;" : "background-color: white"),
  fontcolor: computed(() => SS.darkmode  === "true" ? "color: white;": ""),
  all: computed(()=>theme.bgcolor + theme.fontcolor)
})

</script>
<style scoped>
.bottom-aligner {
  position: absolute;
  bottom: 0;
  width: 50%;
  overflow: auto;
}
a:hover {
  background-color: #757575;
  color: white;
}
</style>