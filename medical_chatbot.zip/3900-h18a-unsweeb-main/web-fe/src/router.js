import { createRouter, createWebHashHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    component: () => import('./views/Home.vue')
  },
  {
    path: '/login',
    component: () => import('./views/Login.vue')
  },
  {
  	path: '/signup',
  	component: () => import('./views/Signup.vue')
  },
  {
  	path: '/chat',
  	component: () => import('./views/Chat.vue')
  },
  {
  	path: '/profile',
  	component: () => import('./views/Profile.vue')
  },
  {
  	path: '/aauth',
  	component: () => import('./views/Aauth.vue')
  }
]

const router = createRouter({ history: createWebHashHistory(), routes }) 

router.afterEach(() => {
  Swal.close()
})

export default router