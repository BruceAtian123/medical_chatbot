'use strict'
/*
 * Telegram bot handler
 */

const TelegramBot = require('node-telegram-bot-api')
const config = require('../config.js')
const axios = require('axios').default
const model = require('../model')

const bot = new TelegramBot(config.tg_token, {
  polling: true
})

console.log('# Telegram Bot Ready')

// handle text messages
async function getTextReply(msg, id) {
  const payload = { history: [], msg, user: id }
  const reply = await axios.post('http://46.101.154.24:5001/text', payload)
  .then(res => res.data)
  .catch(err => 'OOps, something went wrong! Have you chosen the correct mode?')
  return reply
}

// handle search requests
async function getSeachResult(msg, id) {
  const payload = { content: msg, user:id }
  const reply = await axios.post('http://46.101.154.24:5001/search', payload)
  .then(res => res.data)
  .catch(err => 'OOps, something went wrong! Have you chosen the correct mode?')
  return reply
}

// handle image messages
async function getImageResult(msg, url, id) {
  const payload = { question: msg, url: url, user:id }
  const reply = await axios.post('http://46.101.154.24:5001/image', payload)
  .then(res => res.data)
  .catch(err => 'OOps, something went wrong! Have you chosen the correct mode?')
  return reply
}


bot.on('message', async (msg) => {
  const chatId = msg.chat.id
  const image = msg.photo
  let reply
  // handle usual message
  try {
    const res = await model('tg-mode').find({ _id: chatId })
    let curr_mode
    if (res.length != 0) {
      curr_mode = res[0]['mode']
    } else {
      curr_mode = 1 // by default we use chat mode
    }

    // use image if in image mode
    if (curr_mode == 2 && image && image.length > 0) {
      const file_id = image[0]['file_id']

      // the link to download the image
      let url = 'https://api.telegram.org/bot' + config.tg_token + '/getFile?file_id=' + file_id
      const { data } = await axios.get(url)
      url = 'https://api.telegram.org/file/bot' + config.tg_token + '/' + data.result['file_path']
      reply = await getImageResult(msg.caption, url, chatId)
      bot.sendMessage(chatId, reply)
      return 
    }

    // match specific texts
    if (msg.text && (msg.text.match(/\/changemode/) || msg.text.match(/\/start/))) {
      const inline_keyboard = [[
          {
            text: 'Chat mode',
            callback_data: 1
          },
          {
            text: 'Image mode',
            callback_data: 2
          }
        ]]
      bot.sendMessage(msg.chat.id, 'Please choose a mode', {
        reply_markup: { inline_keyboard }
      })
      return
      // general text messages
    } else if (msg.text && (msg.text.match(/\/search/))) {
      reply = await getSeachResult(msg.text.substring(8), chatId)
      for(const r of reply) {
        bot.sendMessage(chatId, JSON.stringify(r, null, 4))
      }
      return
    } else reply = await getTextReply(msg.text, chatId)
    bot.sendMessage(chatId, reply)
  } catch (err) {
    console.log(err)
    bot.sendMessage(chatId, 'Server Error')
  }
})

// change mode callback
bot.on('callback_query',  async query => {
  const { message } = query
  const chatId = message['chat']['id']
  try {
    let res
    switch (query.data) {
      case '1':
        bot.sendMessage(chatId, 'You have chosen chat mode')
        res = await model('tg-mode').find({ _id: chatId })

        // if we don't have record, create one
        if (res.length == 0) {
          await model('tg-mode').insert({ _id: chatId, mode: 1 })
        } else {
          await model('tg-mode').update({ _id: chatId }, { _id: chatId, mode: 1 })
        }
        break
      case '2':
        bot.sendMessage(chatId, 'You have chosen image mode')
        res = await model('tg-mode').find({ _id: chatId })

        // if we don't have record, create one
        if (res.length == 0) {
          await model('tg-mode').insert({ _id: chatId, mode: 2 })
        } else {
          await model('tg-mode').update({ _id: chatId }, { _id: chatId, mode: 2 })
        }
        break
      default:
        console.log(query.data)
      } 
  } catch (err){
      console.log(err)
  }
})