/*
 * start the all the bots
 * and the platform
 */

'use strict'

const express = require('express')
require('./model')
require('./tgBots/tg.js')
require('./slackBots')

const app = express()
const cors = require('cors')
app.use(cors())
app.use(express.json())
app.disable('x-powered-by') // hide express identity

let api = express.Router() // router

app.use('/api', api) // register with middleware


const message = require('./webBots/controllers/message.js')
api.use('/message', message)

const user = require('./webBots/controllers/user.js')
api.use('/user', user)

app.listen(3001, () => {
  console.log('# API server started!')
})