/*
 * [controller/user.js]
 * User Operation
 */

const axios = require('axios')
const express = require('express')
const { aauth } = require('../../config')
const model = require('../../model')
const crypto = require('../utils/crypto')
const router = express.Router()

// login
router.post('/login', async (req, resp) => {
  const username = req.body.username
  const password = req.body.password
  if (!username || !password) {
    resp.status(400).send('Params error')
    return
  }
  const id = crypto.md5(username).toString().replace('.', '_')
  const res = await model('user').find({ _id: id})
  if (!res) resp.status(500).send('Internal Server Error')
  else if (res.length == 0 || res[0].password !== password) resp.status(403).send('Incorrect username or password')
  else resp.send(crypto.sign([Date.now(), id, res[0].role, username])) 
})

// third party login
router.post('/', async (req, resp) => {
  if (!req.body.code) {
    resp.status(400).send('Params error')
    return
  }
  const user = await axios
    .delete(`https://api.aauth.link/login?app=${aauth.id}&secret=${aauth.secret}&code=${req.body.code}`)
    .then(resp => resp.data)
    .catch(err => false)
  if (!user) {
    resp.status(403).send('Login Failed')
    return
  }
  const id = user.id
  delete user.id
  const res = await model('user').find({ _id: id })
  // upsert
  await model('user').update({ _id: id }, user, true)
  resp.send(crypto.sign([Date.now(), id, user.role, user.name]))
})

// change profile
router.put('/:id', async (req, resp) => {
  const role = req.body.role
  const newpwd = req.body.newpwd
  if (!role && !newpwd) {
    resp.status(400).send('Params error')
  }
  const token = req.get('token')
  const user = crypto.verify(token)
  if (!user) {
    resp.status(403).send('auth failed')
    return
  }
  // update db record
  try {
    const doc = {}
    if (newpwd) doc['password'] = newpwd
    if (role) doc['role'] = role
    await model('user').update({ _id: req.params.id }, doc, true)
    resp.send('Success')
  } catch {
    resp.status(500).send('Change failed')
  }
})

router.post('/register', async (req, resp) => {
  const username = req.body.username
  const password = req.body.password
  const role = req.body.role
  if (!username || !password || !role) {
    resp.status(400).send('Params error')
    return
  }
  const user = {
    _id: crypto.md5(username).toString().replace('.', '_'),
    username: username,
    password: password,
    role: role
  }
  const res = await model('user').find({ _id: user._id })
  if (res && res.length > 0) resp.status(403).send('Username already exists')
  else {
    await model('user').insert(user)
    resp.send(crypto.sign([Date.now(), user._id, user.role, username]))
  }
})

module.exports = router