/*
 * [controller/message.js]
 * chat history related Operation
 */

const axios = require('axios')
const express = require('express')
const model = require('../../model')
const crypto = require('../utils/crypto')
const router = express.Router()

// fetch chat histories based on current time
router.get('/fetch/:time', async (req, resp) => {
  const token = req.get('token')
  const user = crypto.verify(token)
  if (!user) {
      resp.status(403).send('auth failed')
      return
  }
  const t = req.params.time
  const res = await model('message').find({ u_id: user[1], timestamp: { $gt: parseInt(t) } }, {})
  if (!res) {
    resp.status(404).send("No more chat history")
  } else {
    resp.send(res.slice(Math.max(res.length - 10, 1)))
  }
})

// send message
router.post('/send', async (req, resp) => {
  const content = req.body.content
  const imageUrl = req.body.imageUrl? req.body.imageUrl: ''
  if (!content) {
    resp.status(400).send('params error')
    return
  }
  const token = req.get('token')
  const user = crypto.verify(token)
  if (!user) {
    resp.status(403).send('auth failed')
    return
  }

  // store message into db
  const msg = {
    _id: user[1] + Date.now(),
    u_id: user[1],
    timestamp: Date.now(),
    imageUrl,
    content,
    user: 'user'
  }
  let res = await model('message').insert(msg)
  if (!res) {
    resp.status(500).send("Internal server error")
    return
  }
  let payload = {}
  let url = ''
  // only text message
  if (!imageUrl) {
    url = 'http://46.101.154.24:5001/text'
    history = await model('message').find({ u_id: user[1], imageUrl: ''}, {}, 4)
    history = history.map(h => h.content)

    if (!history) {
      resp.status(500).send("Internal server error")
      return
    }
    payload = { history: [], msg: content, user: user[1] }
  // with image urls
  } else {
    url = 'http://46.101.154.24:5001/image'
    payload = { question: content, user:user[1], url: imageUrl }
  }

  try {
    // get bot's reply and save it into the db
    const reply = await axios.post(url, payload)
    msg['content'] = reply.data
    msg['user'] = 'bot'
    msg['_id'] = user[1] + Date.now()
    res = await model('message').insert(msg)
    if (!res) {
      resp.status(500).send("Internal server error")
      return
    }
    if (reply.ok) resp.send(reply.data)
    else resp.status(reply.status).send(reply.data)
  } catch {
    resp.send('I\'ll give you some tablets to help you with that.')
  }
  
})

// search chat history
router.get('/history/', async (req, resp) => {

    const token = req.get('token')
    const user = crypto.verify(token)
    const str = req.query.search
    if (!user) {
      resp.status(403).send('auth failed')
      return
    }

    const res = await model('message').find({ u_id: user[1], content: { $regex: str } })
    if (!res || res.length === 0) {
        resp.status(404).send(str)
    } else {
        resp.send(res)
    }
})

// search medical keywords
router.post('/search', async (req, resp) => {
  const content = req.body.content
  if (!content) {
    resp.status(400).send('params error')
    return
  }
  const token = req.get('token')
  const user = crypto.verify(token)
  if (!user) {
    resp.status(403).send('auth failed')
    return
  }
  // store message into db
  const msg = {
    _id: user[1] + Date.now(),
    u_id: user[1],
    timestamp: Date.now(),
    imageUrl: '',
    content,
    user: 'user'
  }
  let res = await model('message').insert(msg)
  if (!res) {
    resp.status(500).send("Internal server error")
    return
  }
  const url = 'http://46.101.154.24:5001/search'
  const payload = { content, user:user[1] }
  // get bot reply and store into db
  const reply = await axios.post(url, payload)
  msg['content'] = reply.data
  msg['user'] = 'bot'
  msg['_id'] = user[1] + Date.now()
  res = await model('message').insert(msg)
  if (!res) {
    resp.status(500).send("Internal server error")
    return
  }
  if (reply.ok) resp.send(reply.data)
  else resp.status(reply.status).send(reply.data)
})
    
module.exports = router