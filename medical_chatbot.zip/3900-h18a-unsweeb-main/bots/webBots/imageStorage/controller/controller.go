package controller

import (
  "acetore/utils"
  "fmt"
  "io"
  "os"
  "github.com/gin-gonic/gin"
)

// file info
type fileInfo struct {
  name   string
  length int
  hash   string
}

// copy file locally
func CopyFile(src string, dest string) error {
  file, err := os.Open(src)
  if err != nil {
    return err
  }
  defer file.Close()
  out, err := os.Create(dest)
  if err != nil {
    return err
  }
  defer out.Close()
  _, err = io.Copy(out, file)
  if err != nil {
    return err
  }
  return nil
}

// Verify the uploaded files
func VerifyUpload(c *gin.Context) {
  hash := c.Param("hash")
  _, err := os.Stat(hash)
    if os.IsNotExist(err) {
        c.String(200, fmt.Sprintf("File does not exist"))
    } else {
      c.String(201, fmt.Sprintf("File exists"))
    }
}

// Upload file
func Upload(c *gin.Context) {
  file, header, err := c.Request.FormFile("file")
  if err != nil {
    c.String(400, fmt.Sprintf("File err : %s", err.Error()))
    return
  }
  tokens := c.Request.Header.Get("token")

  filename := header.Filename
  filepath := "tmp/" + filename
  // if the file doesn't support resume
  if c.Request.Header.Get("Accept-Ranges") != "bytes" {
    // store in tmp
    out, err := os.Create(filepath)
    if err != nil {
      c.String(500, fmt.Sprintf("Internal Server Error : %s", err.Error()))
      return
    }
    defer out.Close()
    _, err = io.Copy(out, file)
    if err != nil {
      c.String(500, fmt.Sprintf("Internal Server Error : %s", err.Error()))
      return
    }
    hash, err := utils.HashFileMd5(filepath)
    // copy to public
    err = CopyFile(filepath, "public/"+hash)
    if err != nil {
      c.String(500, fmt.Sprintf("Internal Server Error : %s", err.Error()))
      return
    }
    utils.Log(tokens + "uploaded file " + filename)
    c.JSON(200, gin.H{"hash": hash})
  } else {

  }
}

