const axios = require('axios');
const dotenv = require('dotenv');
const config = require('../config.js')
const { WebClient } = require('@slack/web-api');
const { App, LogLevel, SocketModeReceiver } = require('@slack/bolt');

const clientOptions = {
    // enable this for dev instance
    // slackApiUrl: 'https://dev.slack.com/api/'
};

console.log('# Slack bot starts!')
let mode = 0

function execShellCommand(cmd) {
    const exec = require('child_process').exec;
    return new Promise((resolve, reject) => {
        exec(cmd, (error, stdout, stderr) => {
            if (error) {
                console.warn(error);
            }
            resolve(stdout? stdout : stderr);
        });
    });
}

// const socketModeReceiver = new SocketModeReceiver({
//   appToken: process.env.APP_TOKEN,
//   installerOptions: {
//     clientOptions,
//     // use the following when running against a dev instance and using OAuth
//     // authorizationUrl: 'https://dev.slack.com/oauth/v2/authorize',
//   },

//   // enable the following if you want to use OAuth
//   // clientId: process.env.CLIENT_ID,
//   // clientSecret: process.env.CLIENT_SECRET,
//   // stateSecret: 'my-state-secret',
//   // scopes: ['channels:read', 'chat:write', 'app_mentions:read', 'channels:manage', 'commands'],

//   logLevel: LogLevel.DEBUG,
// });

console.log('# Slack Bot Ready')
async function getTextReply(msg, id) {
  const payload = { history: [], msg, user: id }
  const reply = await axios.post('http://46.101.154.24:5001/text', payload)
  .then(res => res.data)
  .catch(err => 'OOps, something went wrong!')
  return reply
}

async function getSeachResult(msg, id) {
  const payload = { content: msg, user:id }
  const reply = await axios.post('http://46.101.154.24:5001/search', payload)
  .then(res => res.data)
  .catch(err => 'OOps, something went wrong!')
  return reply
}

async function getImageResult(msg, url, id) {
  const payload = { question: msg, url: url, user:id }
  const reply = await axios.post('http://46.101.154.24:5001/image', payload)
  .then(res => res.data)
  .catch(err => 'OOps, something went wrong!')
  return reply
}

const app = new App({
    // receiver: socketModeReceiver,
    token: config.SLACK_BOT_TOKEN, //disable this if enabling OAuth in socketModeReceiver
    // logLevel: LogLevel.DEBUG,
    clientOptions,
    appToken: config.SLACK_APP_TOKEN,
    socketMode: true,
});

const web = new WebClient(config.SLACK_USER_TOKEN);

(async () => {
    await app.start();
    // console.log('Medbot app started');
})();

// need app_mentions:read and chat:write scopes
app.message(/[\s\S]*/g, async ({ message, say, client }) => {
    console.log("message: " + message.text);
    try {
        const chatId = message.user
        console.log("The current user is: ".concat(chatId))
	    let reply

        if (message.files) {
            types = message.files[0].filetype
            console.log("File type is: " + types)
            validTypes = ["png", "jpg", "jpeg"]

            if (validTypes.includes(types)) {
                fileId = message.files[0].id
                console.log("Get a file:" + fileId)

                const fileObj = await web.files.sharedPublicURL({file: fileId})
                const urlHTML = fileObj["file"]["permalink_public"]

                const pattern = "\"<img src=\\\"https://files.slack.com/files-pri/.\\+\\?pub_secret=..........\\\">\""
                console.log(pattern)
                const imageURL = await execShellCommand("curl -s " + urlHTML + " | " + "grep -o " + pattern)
                const url = imageURL.substring(10, imageURL.length - 3)

                console.log("New public url: " + url)
                console.log("Question: " + message.text)
                reply = await getImageResult(message.text, url, chatId)
                console.log(reply)

                await say({"blocks": [
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": `${reply}`
                        },
                    }
                ]})

                return
            }
        }
        
        if (mode == 1) {
            reply = await getSeachResult(message.text, chatId)
            if (reply.length === 0) reply = 'No results found'
            else {
                for (const r of reply) {
                    await say({"blocks": [
                        {
                            "type": "section",
                            "text": {
                                "type": "mrkdwn",
                                "text": `${JSON.stringify(r, null, 4)}`
                            },
                        }
                    ]})
                }
            }
            return
        } else {
            reply = await getTextReply(message.text, chatId)
        }

        await say({"blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": `${reply}`
                },
            }
        ]})
    }
    catch (error) {
        console.error(error)
    }
});

// Listen to slash command
// need to add commands permission in
// event-subscriptions
app.command('/ask', async ({ command, ack, say }) => {
    // Acknowledge command request
    await ack();

    if (mode == 0) {
        await say("It's text mode");
    } else if (mode == 1) {
        await say("It's search mode")
    }
});

// Listen to slash command
// need to add commands permission in
// event-subscriptions
app.command('/mode', async ({ command, ack, say }) => {
    // Acknowledge command request
    await ack();

    if (mode == 0) {
        mode = 1
        await say("You have switched from text mode to search mode");
    } else if (mode == 1) {
        mode = 0
        await say("You have switched from search mode to text mode")
    }
});