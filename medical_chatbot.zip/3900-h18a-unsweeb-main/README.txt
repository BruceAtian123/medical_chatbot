# Submit time
We have uploaded our final submission to our team’s GitHub classroom account on time (commit history reflect this) 22 April 9.04pm

# Link to github page 
https://github.com/unsw-cse-comp3900-9900-21T1/3900-h18a-unsweeb

# Quick Tour
First, watch the video https://youtu.be/D-XvAmnfkhQ for the first time running this project on your machine. The guide includes the dependencies installation.
If you don’t have Node on your machine, go to https://nodejs.org/en/ to download the LTS version. If you have Node, make sure it is at least Node12.
If you don’t have Python3.8 or higher installed on your machine, go to https://www.python.org/downloads/ to download Python.
If you don’t have Mongodb on your machine or host remotely, download Mongodb from https://www.mongodb.com/try/download/community. If you are using Linux, you might need to install some dependency packages, follow the instructions for your Linux machine https://docs.mongodb.com/manual/administration/install-on-linux/. 
To read the full manual, go to [Manual.pdf]('https://github.com/unsw-cse-comp3900-9900-21T1/3900-h18a-unsweeb/tree/main/Manual.pdf')

# Project Objectives

1. Basic functionalities
    - Account management - Each user has an account on our platform, the user should use their username and password to register/log in. And they are free to change their profile anytime
    - Personalized options - Each user can have their personalized options such as change mode, change font size, change the theme, and save their prefered mode for future usage
    - Platform interactions - Users can manage their chat and have full access to any content related to their chats. 
2. Novel functionalities
    - Support of other platforms - The platform can support using a bot on other platforms such as slack and telegram. It also supports registering using other platform’s accounts such as Facebook. (There is no such functionality in the existing systems, such as Baidu Melody, Tencent Miying and Alibaba ET medical brain.)
    - Support various inputs - The chatbot can handle various inputs including image, voice and text messages. (There is no such functionality in the existing systems, such as Baidu Melody, Tencent Miying and Alibaba ET medical brain.)
    - Deploy knowledge-extraction technology - The platform unifies several knowledge extraction tasks in a comprehensive disease diagnosis aiding chatbot, including documentation prioritization. (There is no such functionality in the existing systems, such as Baidu Melody, Tencent Miying and Alibaba ET medical brain.)
    - Unify knowledge representation - Different datasets are linked by the finely tuned language model, and the same level of medical knowledge can be matched in different tasks such as disease finding extraction, conversation and visual question answering. (There is no such functionality in the existing systems, such as Baidu Melody, Tencent Miying and Alibaba ET medical brain.)
    - Embedded with commonsense knowledge - With the commonsense reasoning module, the chatbot can understand different daily concepts even if they are beyond the medical domain, which can help understanding users’ meaning better. (There is no such functionality in the existing systems, such as Baidu Melody, Tencent Miying and Alibaba ET medical brain.)
    - Ability to find the rare findings in the radiograph - The chatbot can analyze the given radiograph thoroughly from different aspects via the deep learning model, such as organ, plan, size, and disease position. (There is no such functionality in the existing systems, such as Baidu Melody, Tencent Miying and Alibaba ET medical brain.)

# Algorithms
* [Medical Dialogue Generation](https://github.com/unsw-cse-comp3900-9900-21T1/3900-h18a-unsweeb/tree/main/communicator/conversation_model)
* [Medical Visual Question Answering](https://github.com/unsw-cse-comp3900-9900-21T1/3900-h18a-unsweeb/tree/main/communicator/vqa_model)
* [Medical Query Search](https://github.com/unsw-cse-comp3900-9900-21T1/3900-h18a-unsweeb/tree/main/communicator/search_model)

# Front end
* [Front-end](https://github.com/unsw-cse-comp3900-9900-21T1/3900-h18a-unsweeb/tree/main/web-fe/
