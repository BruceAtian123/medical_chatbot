---
name: User Story Issue Template
about: This template provides the format of raising user-story-related issues.
title: ''
labels: ''
assignees: ''

---

**Related User Story:**
<!-- Link Issues on JIra by using [CHW-NUMBER], e.g.  [CHW-1]-->

**Desired Functionality:**
<!-- Describe your desired functionality after adding the feature/s.-->
