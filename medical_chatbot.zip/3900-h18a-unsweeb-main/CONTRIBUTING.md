# Software:
## Front-end Design(Ranked from the most to the least based on the contribution):
  * Queenie Ji
  * Tina Ji
  * Terry Zhuo & Patrick Dong & Austin Xie

## Back-end without the Model Algorithm Design(Ranked from the most to the least based on the contribution):
  * Tina Ji
  * Terry Zhuo
  * Queenie Ji & Patrick Dong
  * Austin Xie

## Model Algorithm (Ranked from the most to the least based on the contribution):
  * Terry Zhuo
  * Queenie Ji & Tina Ji & Patrick Dong & Austin Xie
 
## Debug (Ranked from the most to the least based on the contribution):
  * Tina Ji & Terry Zhuo
  * Patrick Dong  & Queenie Ji
  * Austin Xie

# Paperwork:
## Proposal (Ranked from the most to the least based on the contribution):
  * Queenie Ji & Terry Zhuo & Tina Ji
  * Patrick Dong
  * Austin Xie

## Retrospective A & B (Ranked from the most to the least based on the contribution):
  * Patrick Dong
  * Queenie Ji & Terry Zhuo & Tina Ji
  * Austin Xie

## Final Report and Video Making (Ranked from the most to the least based on the contribution):
  * Queenie Ji & Terry Zhuo & Tina Ji & Patrick Dong
  * Austin Xie

# Total Ranking:
  1. Queenie Ji & Terry Zhuo & Tina Ji & Patrick Dong (almost contribute equally)
  2. Austin Xie
