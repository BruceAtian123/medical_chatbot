import sys
sys.path.insert(1,"../search_model")
import plac
import time
import logging
import torch
from math import ceil
from operator import itemgetter
from pyserini.search import querybuilder,SimpleSearcher
from sentence_transformers import InputExample
from sentence_transformers.cross_encoder import CrossEncoder

LOGIC_TERM=["AND", "NOT", "OR"]

class QeuryBuilder(object):
    def __init__(self, text_logic):
        self.text_logic=text_logic
    
    def build(self):
        boolean_query_builder = querybuilder.get_boolean_query_builder()
        query_split = self.text_logic.split()
        mark_index=1
        prev_term=None
        for index,ele in enumerate(query_split):
            if ele in LOGIC_TERM:
                if prev_term:
                    term = querybuilder.get_term_query(" ".join(query_split[mark_index:index]))
                    logic = querybuilder.JBooleanClauseOccur[prev_term].value
                    boolean_query_builder.add(term, logic)
                    mark_index=index+1

                if ele == "AND":
                    prev_term = "must"
                elif ele == "NOT":
                    prev_term = "must_not" 
                elif ele == "OR":
                    prev_term = "should"
        return boolean_query_builder.build()


class QueryFinder(object):
    def __init__(self, query, logic=False, top_k=10, cross_encoder="sentence-transformers/ce-distilroberta-base-stsb",
                indexes="search_model/indexes/small_collection_with_dup_jsonl"):
        
        self.reranker = CrossEncoder(cross_encoder)
        self.bm25_searcher = SimpleSearcher(indexes)
        self.bm25_searcher.set_bm25(0.9, 0.4)
        self.bm25_searcher.set_rm3(10, 10, 0.5)
        self.top_k=top_k
        # if logic:
        #     # Currently only support logics based on logic terms' orders inside the given query
        #     # Please give the boolean query in the format of:
        #     # "LOGIC1 term1 LOGIC2 term3 LOGIC3 term3... "
        #     self.query = QeuryBuilder.build(query)
        # else:
        #     self.query = query
        self.query = query
        
    def search(self):
        return self.bm25_searcher.search(self.query, k=10)
    
    def rerank(self):
        hits = self.search()
        hit_scores = [(hit, self.reranker.predict([hit.contents, self.query])) for hit in hits]
        torch.cuda.empty_cache()
        return sorted(hit_scores, key=itemgetter(1), reverse=True)[:3]
