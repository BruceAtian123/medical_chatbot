import pickle

class MyDataLoader(object):
    def __init__(self, para_len_dir, para_list_dir, report_list_dir):
        with open("../search_model/"+para_len_dir,"rb") as f:
            self.para_len = pickle.load(f)
        with open("../search_model/"+para_list_dir,"rb") as f:
            self.para_list = pickle.load(f)
        with open("../search_model/"+report_list_dir,"rb") as f:
            self.report_list = pickle.load(f)

class HistoryFinder(object):
    def __init__(self, hits_with_scores, para_len_dir, para_list_dir, report_list_dir):
        self.hits = [hs[0] for hs in hits_with_scores]
        self.data = MyDataLoader(para_len_dir, para_list_dir, report_list_dir)
    
    def report_search(self,result_index):
            for report_idx, para_index in enumerate(self.data.para_len):
                if result_index in range(para_index[0], para_index[1]+1):
                    return self.data.report_list[report_idx]
    
    def find(self):
        return [self.data.para_list[int(hit.docid.replace("doc",""))] for hit in self.hits],\
            [self.report_search(int(hit.docid.replace("doc",""))) for hit in self.hits]
    

