# Search Engine
A search engine helps clinicians find more relevant findings.

## Requirements
* Please note the search engine requires Python 3.6+ and Java 11.

## System
* Currently, users can search a simple query without the boolean logic. The boolean logic parser is still under construction. 
* We use [Pyserini](https://github.com/castorini/pyserini) to do the query search on BM25 and RM3.
* The reranking function is provided by [SBERT-cross_enoder](https://www.sbert.net/examples/applications/cross-encoder/README.html).

## Data
* Please contact the author for `para_len.lib`, `para_list.lib`, `report_list.lib` & `collection_with_dup_jsonl`.

## Playground
See `use_search_engine.ipynb` in the folder for more information.