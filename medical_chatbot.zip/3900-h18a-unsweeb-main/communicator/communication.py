from flask import Flask, request, jsonify
import sys
sys.path.insert(1,"./search_model")
import QuerySearcher
import HistoryFinder
import torch
from transformers import AutoModelWithLMHead, AutoTokenizer
import requests
import shutil
sys.path.insert(1,"./vqa_model")
sys.path.insert(1,"./vqa_model/data_RAD")
from run_vqa import *
APP = Flask(__name__, static_url_path="/static", static_folder="static")

# process user sent text and reply
@APP.route("/text", methods=['POST'])
def getText():
    # error handling
    try:
        message = request.get_json()['msg']
        history = request.get_json()['history']
        uid = request.get_json()['user']
    except Exception:
        return 'Bad Request', 400
    tokenizer = AutoTokenizer.from_pretrained('microsoft/DialoGPT-small')
    model = AutoModelWithLMHead.from_pretrained('med_sense')

    # process messages with histories
    user_chat = message + tokenizer.eos_token
    new_user_input_ids = tokenizer.encode(user_chat, return_tensors='pt')
    history_ids = None
    for chat in history:
        if history_ids != None:
            history_ids = torch.cat([history_ids,tokenizer.encode(chat + tokenizer.eos_token, return_tensors='pt')], dim=-1) 
        else:
             history_ids = tokenizer.encode(chat + tokenizer.eos_token, return_tensors='pt')
    bot_input_ids = torch.cat([history_ids, new_user_input_ids], dim=-1) if history else new_user_input_ids
    chat_history_ids = model.generate(
        bot_input_ids, max_length=10240,
        pad_token_id=tokenizer.eos_token_id,  
        no_repeat_ngram_size=3,       
        do_sample=True, 
        top_k=100, 
        top_p=0.7,
        temperature = 0.8
    )

    # pretty print last ouput tokens from bot
    bot_chat = tokenizer.decode(chat_history_ids[:, bot_input_ids.shape[-1]:][0], skip_special_tokens=True)
    print("MedBot: {}".format(bot_chat))
    return jsonify(bot_chat)

# process user search requests
@APP.route("/search", methods=['POST'])
def getSearch():
    try:
        message = request.get_json()['content']
        uid = request.get_json()['user']
    except Exception:
        return 'Bad Request', 400
    find_query = QuerySearcher.QueryFinder(message)
    finder = HistoryFinder.HistoryFinder(
                find_query.rerank(),
                "small_para_len.lib",
                "small_para_list.lib",
                "small_report_list.lib")
    paras, reports = finder.find()
    return jsonify(reports)

# process user search requests
@APP.route("/image", methods=['POST'])
def getImage():
    try:
        question = request.get_json()['question']
    except Exception:
        return 'Please ask a question'
    try:
        url = request.get_json()['url']
    except Exception:
        return 'Bad Request', 400

    # download image from given url
    r = requests.get(url = url, stream = True)
    print(url)
    filename = url[-20] + '.jpg'
    filepath = ''
    if r.status_code == 200:
        r.raw.decode_content = True
        with open(filename,'wb') as f:
            shutil.copyfileobj(r.raw, f)
            filepath = "./" + filename            
    else:
        return 'could not get image', 400

    # process images
    args = parse_args()
    torch.backends.cudnn.benchmark = True
    args.device = torch.device("cuda:" + str(args.gpu) if args.gpu >= 0 else "cpu")
    if args.use_RAD:
        dictionary = my_dataset_RAD.Dictionary.load_from_file(os.path.join(args.RAD_dir , 'dictionary.pkl'))
        eval_dset = my_dataset_RAD.VQAFeatureDataset(args.split, args, dictionary,filepath)
    batch_size = args.batch_size
    constructor = 'build_%s' % args.model
    model = getattr(base_model, constructor)(eval_dset, args)
    eval_loader = DataLoader(eval_dset, batch_size, shuffle=False, num_workers=0, pin_memory=True, collate_fn=utils.trim_collate)

    def save_questiontype_results(outfile_path, quesntion_types_result):
        for i in quesntion_types_result:
            pd.DataFrame(quesntion_types_result[i]).transpose().to_csv(outfile_path + '/question_type_' + i + '.csv')

    # Testing process
    def process(args, model, eval_loader):
        model_path = args.input + '/model_epoch%s.pth' % args.epoch
    #         print('loading %s' % model_path)
        model_data = torch.load(model_path, map_location=torch.device('cpu'))

        # Comment because do not use multi gpu
        # model = nn.DataParallel(model)
        model = model.to(args.device)
        model.load_state_dict(model_data.get('model_state', model_data))

        model.train(False)
        # if args.use_RAD:
        preds = get_result(model, eval_loader, args.device, args, question)
        return preds
    return process(args, model, eval_loader)


# run the server on port 5000
if __name__ == '__main__':
    PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 5000
    APP.run(port=PORT, debug=True)