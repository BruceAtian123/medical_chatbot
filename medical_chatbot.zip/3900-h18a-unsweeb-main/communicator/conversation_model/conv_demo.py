import torch
from transformers import AutoModelWithLMHead, AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained('microsoft/DialoGPT-small')
model = AutoModelWithLMHead.from_pretrained('checkpoint-35000')

total_chat_history = [] # Database History

# encode the new user input, add the eos_token and return a tensor in Pytorch
user_chat = input(">> User:") + tokenizer.eos_token
total_chat_history.append(user_chat)
new_user_input_ids = tokenizer.encode(user_chat, return_tensors='pt')
# print(new_user_input_ids)

# append the new user input tokens to the chat history
history_ids = []
for chat in total_chat_history[-4:]:
    history_ids.extend(tokenizer.encode(chat + tokenizer.eos_token, return_tensors='pt'))

bot_input_ids = torch.cat([history_ids, new_user_input_ids], dim=-1) if len(total_chat_history) > 0 else new_user_input_ids

# generated a response while limiting the total chat history to 10240 tokens, 
chat_history_ids = model.generate(
    bot_input_ids, max_length=10240,
    pad_token_id=tokenizer.eos_token_id,  
    no_repeat_ngram_size=3,       
    do_sample=True, 
    top_k=100, 
    top_p=0.7,
    temperature = 0.8
)

# pretty print last ouput tokens from bot
bot_chat = tokenizer.decode(chat_history_ids[:, bot_input_ids.shape[-1]:][0], skip_special_tokens=True)
print("MedBot: {}".format(bot_chat))
total_chat_history.append(bot_chat)