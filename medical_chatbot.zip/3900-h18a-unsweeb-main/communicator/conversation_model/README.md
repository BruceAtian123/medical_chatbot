# MedBot
A chatbot helps clinicians be more professional.

## Model
* We provide a checkpoint of the model finetuned on [DialogGPT-small](https://github.com/microsoft/DialoGPT). The model is trained on 3 V100 GPUs. 
* The dataset is [MedDialog-EN](https://github.com/UCSD-AI4H/Medical-Dialogue-System).
* You can download the model from [here](https://drive.google.com/drive/folders/1yeTX-a-j9cR9mXj5ZW1b4u-pZ6vsFrJk?usp=sharing)

## Training
* You can train the model by running `python train_medbot.py`.

## Playground
See `talk_to_MedBot.ipynb` in the folder for more information.
