#!/usr/bin/env bash
## <link>
## This code is written by Binh X. Nguyen
## Script for downloading preprocessed VQA-RAD data
mkdir data_RAD
wget "link"
unzip data_RAD.zip -d data_RAD