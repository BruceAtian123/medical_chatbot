"""
This code is modified based on Jin-Hwa Kim's repository (Bilinear Attention Networks - https://github.com/jnhwkim/ban-vqa) by Xuan B. Nguyen
"""
from __future__ import print_function
import os
import json
import random
import _pickle as cPickle
import cv2
import matplotlib.pyplot as plt
import numpy as np
import utils
import torch
from language_model import WordEmbedding
from torch.utils.data import Dataset
import itertools
import warnings
with warnings.catch_warnings():
    warnings.filterwarnings("ignore",category=FutureWarning)
COUNTING_ONLY = False
import sys
sys.path.insert(1,"data_RAD")
# Following Trott et al. (ICLR 2018)
#   Interpretable Counting for Visual Question Answering
def is_howmany(q, a, label2ans):
    if 'how many' in q.lower() or \
       ('number of' in q.lower() and 'number of the' not in q.lower()) or \
       'amount of' in q.lower() or \
       'count of' in q.lower():
        if a is None or answer_filter(a, label2ans):
            return True
        else:
            return False
    else:
        return False

def answer_filter(answers, label2ans, max_num=10):
    for ans in answers['labels']:
        if label2ans[ans].isdigit() and max_num >= int(label2ans[ans]):
            return True
    return False

class Dictionary(object):
    def __init__(self, word2idx=None, idx2word=None):
        if word2idx is None:
            word2idx = {}
        if idx2word is None:
            idx2word = []
        self.word2idx = word2idx
        self.idx2word = idx2word

    @property
    def ntoken(self):
        return len(self.word2idx)

    @property
    def padding_idx(self):
        return len(self.word2idx)

    def tokenize(self, sentence, add_word):
        sentence = sentence.lower()
        if "? -yes/no" in sentence:
            sentence = sentence.replace("? -yes/no", "")
        if "? -open" in sentence:
            sentence = sentence.replace("? -open", "")
        if "? - open" in sentence:
            sentence = sentence.replace("? - open", "")
        sentence = sentence.replace(',', '').replace('?', '').replace('\'s', ' \'s').replace('...', '').replace('x ray', 'x-ray').replace('.', '')
        words = sentence.split()
        tokens = []
        if add_word:
            for w in words:
                tokens.append(self.add_word(w))
        else:
            for w in words:
                # if a word is not in dictionary, it will be replaced with the last word of dictionary.
                tokens.append(self.word2idx.get(w, self.padding_idx-1))
        return tokens

    def dump_to_file(self, path):
        cPickle.dump([self.word2idx, self.idx2word], open(path, 'wb'))
        print('dictionary dumped to %s' % path)

    @classmethod
    def load_from_file(cls, path):
        print('loading dictionary from %s' % path)
        word2idx, idx2word = cPickle.load(open(path, 'rb'))
        d = cls(word2idx, idx2word)
        return d

    def add_word(self, word):
        if word not in self.word2idx:
            self.idx2word.append(word)
            self.word2idx[word] = len(self.idx2word) - 1
        return self.word2idx[word]

    def __len__(self):
        return len(self.idx2word)

def _create_entry(data):
    entry = {
        'question'    : data['question'],
        'phrase_type' : data['phrase_type']}
    return entry

def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError:
        return False
    return True

class VQAFeatureDataset(Dataset):
    def __init__(self, name, args, dictionary, images_path, dataroot='data', question_len=12):
        super(VQAFeatureDataset, self).__init__()
        self.args = args
        assert name in ['train', 'test']
        dataroot = args.RAD_dir
        ans2label_path = os.path.join(dataroot, 'cache', 'trainval_ans2label.pkl')
        label2ans_path = os.path.join(dataroot, 'cache', 'trainval_label2ans.pkl')
        self.ans2label = cPickle.load(open(ans2label_path, 'rb'))
        self.label2ans = cPickle.load(open(label2ans_path, 'rb'))
        self.num_ans_candidates = len(self.ans2label)

        # End get the number of answer type class
        self.dictionary = dictionary

        # TODO: load img_id2idx
        self.img_id2idx = json.load(open(os.path.join(dataroot, 'imgid2idx.json')))

        
        # load image data for MAML module
        if args.not_random:
            img = cv2.cvtColor(cv2.imread(images_path), cv2.COLOR_BGR2GRAY)
        else:
            index = random.randrange(315)
        if args.maml:
            # TODO: load images
            if args.not_random:
                self.maml_images_data = cv2.resize(img, dsize=(84, 84))
            else:
                images_path = os.path.join(dataroot, 'images84x84.pkl')
                # print('loading MAML image data from file: '+ images_path)
                self.maml_images_data = cPickle.load(open(images_path, 'rb'))[index]
#             plt.title('Input Image (84x84)')
#             plt.imshow(self.maml_images_data)
#             plt.show(block=True)
        # load image data for Auto-encoder module
        if args.autoencoder:
            # TODO: load images
            if args.not_random:
                self.ae_images_data = cv2.resize(img, dsize=(128, 128))
            else:
                images_path = os.path.join(dataroot, 'images128x128.pkl')
                # print('loading DAE image data from file: '+ images_path)
                self.ae_images_data = cPickle.load(open(images_path, 'rb'))[index]
#             plt.title('Input Image (128x128)')
#             plt.imshow(self.ae_images_data)
#             plt.show(block=True)
        
        # self.entries = _load_dataset()

        # tokenization
        # self.tokenize(question_len)
        self.tensorize()
        if args.autoencoder and args.maml:
            self.v_dim = args.feat_dim * 2
        else:
            self.v_dim = args.feat_dim

    def tensorize(self):
        if self.args.maml:
            self.maml_images_data = torch.from_numpy(self.maml_images_data)
            self.maml_images_data = self.maml_images_data.type('torch.FloatTensor')
        if self.args.autoencoder:
            self.ae_images_data = torch.from_numpy(self.ae_images_data)
            self.ae_images_data = self.ae_images_data.type('torch.FloatTensor')

    def __getitem__(self, index):
        # entry = self.entries[index]
        # question = entry['q_token']

        image_data = [0, 0]
        if self.args.maml:
            maml_images_data = self.maml_images_data.reshape(84*84)
            image_data[0] = maml_images_data
        if self.args.autoencoder:
            ae_images_data = self.ae_images_data.reshape(128*128)
            image_data[1] = ae_images_data

        return image_data

    def __len__(self):
        return 1
